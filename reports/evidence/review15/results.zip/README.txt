T07 G07 original review15 submission
60 synthetic images; seed42; 14 approve + 1 edit.
45 outside-queue images retain original machine output.
Status: HOLD / INDEPENDENT_QA_PENDING.
