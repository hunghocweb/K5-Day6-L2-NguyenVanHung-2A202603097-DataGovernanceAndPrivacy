T07 G07: recorded review15 candidate, not a validated release.
60 synthetic images, seed42, dev36/eval24; only original top15 edits applied.
45 outside-queue PNGs match original PoC byte-for-byte.
Raw source journals are included for provenance; additional web decisions are not added to B=15.
Known rejected cases remain; inspect decision.json. No GT metrics or new human decisions generated.
Replay: python -m tools.prepare_t07_submission (requires original local run/review artifacts).
Official evaluation: python -m src.evaluate --track t07 --pred reports/evidence/review15/redactions.csv --split eval
